@extends('layouts.main')

@section('content')
    <h1>hola</h1>
@endsection
 
